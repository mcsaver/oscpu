`include "define.v"

// DPI-C 仿真顶层：只负责把可综合 NpcCore 接到独立总线和宿主侧事件模型。
// 该文件不能进入 RTL_CORE_SRCS/STA_RTL_FILES。

import "DPI-C" function void npc_commit_event(
  input longint unsigned pc,
  input int unsigned inst,
  input longint unsigned next_pc,
  input int unsigned rd_en,
  input int unsigned rd_addr,
  input longint unsigned rd_data,
  input int unsigned is_fp   // 阶段2 FPR shadow: 该提交是否 FP rd 写(rd_addr/rd_data 复用为 FP addr/结果)
);

import "DPI-C" function void npc_exit_event(
  input int unsigned is_ebreak,
  input int unsigned is_ecall,
  input int unsigned is_system_reset,
  input longint unsigned code,
  input longint unsigned pc
);

// 全状态 difftest: 每 commit 拍 XMR 读 CsrFile 的 CSR+priv 快照(23 槽, 索引约定见 difftest.h)。
// 用 23 个 scalar 参数(scalar 传递自动 4→2 state 转换; unpacked array DPI 的 shape 匹配过严)。
import "DPI-C" function void npc_arch_csr_event(
  input longint unsigned c0,  input longint unsigned c1,  input longint unsigned c2,
  input longint unsigned c3,  input longint unsigned c4,  input longint unsigned c5,
  input longint unsigned c6,  input longint unsigned c7,  input longint unsigned c8,
  input longint unsigned c9,  input longint unsigned c10, input longint unsigned c11,
  input longint unsigned c12, input longint unsigned c13, input longint unsigned c14,
  input longint unsigned c15, input longint unsigned c16, input longint unsigned c17,
  input longint unsigned c18, input longint unsigned c19, input longint unsigned c20,
  input longint unsigned c21, input longint unsigned c22
);

// 阶段2: 每 commit 拍 XMR 读 arch FPR(32×64bit) 快照(32 scalar, 对称 CSR)。
import "DPI-C" function void npc_arch_fpr_event(
  input longint unsigned f0,  input longint unsigned f1,  input longint unsigned f2,
  input longint unsigned f3,  input longint unsigned f4,  input longint unsigned f5,
  input longint unsigned f6,  input longint unsigned f7,  input longint unsigned f8,
  input longint unsigned f9,  input longint unsigned f10, input longint unsigned f11,
  input longint unsigned f12, input longint unsigned f13, input longint unsigned f14,
  input longint unsigned f15, input longint unsigned f16, input longint unsigned f17,
  input longint unsigned f18, input longint unsigned f19, input longint unsigned f20,
  input longint unsigned f21, input longint unsigned f22, input longint unsigned f23,
  input longint unsigned f24, input longint unsigned f25, input longint unsigned f26,
  input longint unsigned f27, input longint unsigned f28, input longint unsigned f29,
  input longint unsigned f30, input longint unsigned f31
);

import "DPI-C" function void npc_mmio_load_event();
import "DPI-C" function void npc_trap_event(
  input int unsigned cause,
  input longint unsigned pc,
  input longint unsigned tval
);

import "DPI-C" function void npc_handled_trap_event(
  input int unsigned kind,
  input int unsigned cause,
  input longint unsigned pc,
  input longint unsigned tval
);

`ifdef CONFIG_NPC_BRANCH_STATS
import "DPI-C" function void npc_bpu_lookup_event(
  input int unsigned is_branch,
  input int unsigned is_jalr,
  input int unsigned is_ret,
  input int unsigned btb_hit,
  input int unsigned bht_valid,
  input int unsigned ras_lookup,
  input int unsigned ras_hit,
  input int unsigned ras_overflow
);

import "DPI-C" function void npc_bpu_resolve_event(
  input int unsigned is_branch,
  input int unsigned pc,
  input int unsigned is_jal,
  input int unsigned is_jalr,
  input int unsigned is_ret,
  input int unsigned pred_taken,
  input int unsigned actual_taken,
  input int unsigned correct
);
`endif

`ifdef CONFIG_NPC_CACHE_STATS
import "DPI-C" function void npc_icache_event(
  input int unsigned access,
  input int unsigned hit,
  input int unsigned miss
);

import "DPI-C" function void npc_dcache_event(
  input int unsigned access,
  input int unsigned hit,
  input int unsigned miss,
  input int unsigned writeback,
  input int unsigned write_through,
  input int unsigned is_store
);
`endif

`ifdef CONFIG_NPC_OOO_STATS
import "DPI-C" function void npc_ooo_cycle_event(
  input int unsigned retire_count,
  input int unsigned execute_count,
  input int unsigned dispatch_count,
  input int unsigned fetch_req_valid,
  input int unsigned fetch_req_fire,
  input int unsigned fetch_rsp_fire,
  input int unsigned fetch_rsp_enqueue,
  input int unsigned fetch_rsp_bypass,
  input int unsigned stop_pending,
  input int unsigned pending_branch,
  input int unsigned pending_jump,
  input int unsigned pending_mem,
  input int unsigned synth_ret_pending,
  input int unsigned branch_prefetch_fire,
  input int unsigned branch_prefetch_hit,
  input int unsigned mem0_req_fire,
  input int unsigned mem1_req_fire,
  input int unsigned mem0_rsp_fire,
  input int unsigned mem1_rsp_fire,
  input int unsigned commit1_block,
  input int unsigned fetch_busy,
  input int unsigned mem_busy,
  input int unsigned axi_wait,
  input int unsigned hazard_busy,
  input int unsigned branch_flush,
  input int unsigned exception_busy,
  input longint unsigned pending_branch_pc,
  input longint unsigned pending_jump_pc
);
`endif

import "DPI-C" function void npc_uart_event(
  input int unsigned is_write,
  input int unsigned tx_valid,
  input int unsigned tx_data,
  input int unsigned access_addr,
  input longint unsigned access_wdata,
  input int unsigned access_wstrb,
  input longint unsigned access_rdata
);

import "DPI-C" function int npc_uart_rx_pop(
  output int unsigned data
);

import "DPI-C" function void npc_irq_event(
  input int unsigned uart_irq,
  input int unsigned plic_irq
);

`ifndef CONFIG_NPC_UART_RX_POLL_SHIFT
`define CONFIG_NPC_UART_RX_POLL_SHIFT 0
`endif

module NpcSimTop (
  input logic clk,
  input logic rst,

  output logic [`XLEN-1:0] debug_pc_o,
  output logic [`CORE_STATE_W-1:0] debug_state_o,
  output logic [63:0] debug_ooo_flags_o,
  output logic [63:0] debug_ooo_satp_o,
  output logic [63:0] debug_bus_flags_o,
  output logic [63:0] debug_bus2_flags_o,
  output logic [63:0] debug_fetch_addr_o,
  output logic [63:0] debug_mem_addr_o,
  output logic [63:0] debug_fetch_pte_addr_o,
  output logic [63:0] debug_fetch_pte_o,
  output logic [63:0] debug_fetch_pte_meta_o,
  output logic [63:0] debug_clint_mtime_o
);

`ifdef CONFIG_NPC_DEBUG_PORTS
  localparam [3:0] AXI_S_CLINT = 4'd0;
  localparam [3:0] AXI_S_RESET_SYSCON = 4'd2;
  localparam [3:0] AXI_S_UART = 4'd3;
  localparam [3:0] AXI_S_DEFAULT = 4'd15;
`endif
  logic psram_axi_arvalid_w;
  logic psram_axi_arready_w;
  logic [`XLEN-1:0] psram_axi_araddr_w;
  logic [2:0] psram_axi_arsize_w;
  logic [2:0] psram_axi_arprot_w;
  logic psram_axi_rvalid_w;
  logic psram_axi_rready_w;
  logic [`XLEN-1:0] psram_axi_rdata_w;
  logic [1:0] psram_axi_rresp_w;
  logic psram_axi_awvalid_w;
  logic psram_axi_awready_w;
  logic [`XLEN-1:0] psram_axi_awaddr_w;
  logic [2:0] psram_axi_awsize_w;
  logic psram_axi_wvalid_w;
  logic psram_axi_wready_w;
  logic [`XLEN-1:0] psram_axi_wdata_w;
  logic [`STRB_W-1:0] psram_axi_wstrb_w;
  logic psram_axi_bvalid_w;
  logic psram_axi_bready_w;
  logic [1:0] psram_axi_bresp_w;

  logic sdram_axi_arvalid_w;
  logic sdram_axi_arready_w;
  logic [`XLEN-1:0] sdram_axi_araddr_w;
  logic [2:0] sdram_axi_arsize_w;
  logic [2:0] sdram_axi_arprot_w;
  logic sdram_axi_rvalid_w;
  logic sdram_axi_rready_w;
  logic [`XLEN-1:0] sdram_axi_rdata_w;
  logic [1:0] sdram_axi_rresp_w;
  logic sdram_axi_awvalid_w;
  logic sdram_axi_awready_w;
  logic [`XLEN-1:0] sdram_axi_awaddr_w;
  logic [2:0] sdram_axi_awsize_w;
  logic sdram_axi_wvalid_w;
  logic sdram_axi_wready_w;
  logic [`XLEN-1:0] sdram_axi_wdata_w;
  logic [`STRB_W-1:0] sdram_axi_wstrb_w;
  logic sdram_axi_bvalid_w;
  logic sdram_axi_bready_w;
  logic [1:0] sdram_axi_bresp_w;

  logic legacy_mmio_axi_arvalid_w;
  logic legacy_mmio_axi_arready_w;
  logic [`XLEN-1:0] legacy_mmio_axi_araddr_w;
  logic [2:0] legacy_mmio_axi_arsize_w;
  logic [2:0] legacy_mmio_axi_arprot_w;
  logic legacy_mmio_axi_rvalid_w;
  logic legacy_mmio_axi_rready_w;
  logic [`XLEN-1:0] legacy_mmio_axi_rdata_w;
  logic [1:0] legacy_mmio_axi_rresp_w;
  logic legacy_mmio_axi_awvalid_w;
  logic legacy_mmio_axi_awready_w;
  logic [`XLEN-1:0] legacy_mmio_axi_awaddr_w;
  logic [2:0] legacy_mmio_axi_awsize_w;
  logic legacy_mmio_axi_wvalid_w;
  logic legacy_mmio_axi_wready_w;
  logic [`XLEN-1:0] legacy_mmio_axi_wdata_w;
  logic [`STRB_W-1:0] legacy_mmio_axi_wstrb_w;
  logic legacy_mmio_axi_bvalid_w;
  logic legacy_mmio_axi_bready_w;
  logic [1:0] legacy_mmio_axi_bresp_w;

  logic virtio_blk_axi_arvalid_w;
  logic virtio_blk_axi_arready_w;
  logic [`XLEN-1:0] virtio_blk_axi_araddr_w;
  logic [2:0] virtio_blk_axi_arsize_w;
  logic [2:0] virtio_blk_axi_arprot_w;
  logic virtio_blk_axi_rvalid_w;
  logic virtio_blk_axi_rready_w;
  logic [`XLEN-1:0] virtio_blk_axi_rdata_w;
  logic [1:0] virtio_blk_axi_rresp_w;
  logic virtio_blk_axi_awvalid_w;
  logic virtio_blk_axi_awready_w;
  logic [`XLEN-1:0] virtio_blk_axi_awaddr_w;
  logic [2:0] virtio_blk_axi_awsize_w;
  logic virtio_blk_axi_wvalid_w;
  logic virtio_blk_axi_wready_w;
  logic [`XLEN-1:0] virtio_blk_axi_wdata_w;
  logic [`STRB_W-1:0] virtio_blk_axi_wstrb_w;
  logic virtio_blk_axi_bvalid_w;
  logic virtio_blk_axi_bready_w;
  logic [1:0] virtio_blk_axi_bresp_w;

  logic uart_tx_valid_w;
  logic [7:0] uart_tx_data_w;
  logic uart_access_valid_w;
  logic uart_access_write_w;
  logic [11:0] uart_access_addr_w;
  logic [`XLEN-1:0] uart_access_wdata_w;
  logic [`STRB_W-1:0] uart_access_wstrb_w;
  logic [`XLEN-1:0] uart_access_rdata_w;
  logic uart_rx_valid_q;
  logic [7:0] uart_rx_data_q;
  logic uart_rx_ready_w;
  logic [31:0] uart_rx_poll_q;
  logic [63:0] clint_mtime_w;
  logic plic_external_irq_w;
  logic uart_irq_w;
  logic virtio_blk_irq_w;
  logic virtio_blk_dma_dcache_invalidate_all_w;
  logic sim_icache_access_w;
  logic sim_icache_hit_w;
  logic sim_icache_miss_w;
  logic sim_dcache_access_w;
  logic sim_dcache_hit_w;
  logic sim_dcache_miss_w;
  logic sim_dcache_store_access_w;
  logic sim_dcache_writeback_w;
  logic sim_dcache_write_through_w;
  logic sim_control_event_w;
  logic sim_bpu_lookup_event_w;
  logic sim_bpu_ret_resolve_w;
  logic sim_bpu_pred_taken_w;
  logic sim_bpu_resolve_correct_w;
  logic exit_reported_q;
  logic uart_irq_prev_q;
  logic plic_irq_prev_q;
  logic reset_syscon_write_valid_w;
  logic [31:0] reset_syscon_write_value_w;

  function automatic logic sim_is_link_reg(input logic [4:0] reg_idx);
    begin
      sim_is_link_reg = (reg_idx == 5'd1) || (reg_idx == 5'd5);
    end
  endfunction

  logic core_commit0_valid_w;
  logic [`XLEN-1:0] core_commit0_pc_w;
  logic [`INST_W-1:0] core_commit0_inst_w;
  logic [`XLEN-1:0] core_commit0_next_pc_w;
  logic core_commit0_rd_en_w;
  logic [`REG_ADDR_W-1:0] core_commit0_rd_addr_w;
  logic [`XLEN-1:0] core_commit0_rd_data_w;
  logic core_commit0_exception_w;
  logic core_commit0_write_w;
  logic core_commit1_valid_w;
  logic [`XLEN-1:0] core_commit1_pc_w;
  logic [`INST_W-1:0] core_commit1_inst_w;
  logic [`XLEN-1:0] core_commit1_next_pc_w;
  logic core_commit1_rd_en_w;
  logic [`REG_ADDR_W-1:0] core_commit1_rd_addr_w;
  logic [`XLEN-1:0] core_commit1_rd_data_w;
  logic core_commit1_exception_w;
  logic core_commit1_write_w;
  logic core_trap_valid_w;
  logic [`TRAP_CAUSE_W-1:0] core_trap_cause_w;
  logic [`XLEN-1:0] core_trap_pc_w;
  logic [`XLEN-1:0] core_trap_tval_w;
  logic core_exit_valid_w;
  logic core_exit_is_ecall_w;
  logic core_exit_is_ebreak_w;
  logic [`XLEN-1:0] core_exit_code_w;
  logic [`XLEN-1:0] core_exit_pc_w;
  logic core_halted_w;
  logic [1:0] core_retire_count_w;
  logic [6:0] core_free_count_w;
  logic [4:0] core_rob_count_w;
  logic [3:0] core_issue_count_w;

  wire reset_syscon_poweroff_w =
      reset_syscon_write_valid_w &&
      (reset_syscon_write_value_w == 32'h0000_5555);
  wire reset_syscon_reboot_w =
      reset_syscon_write_valid_w &&
      (reset_syscon_write_value_w == 32'h0000_7777);
  wire reset_syscon_finisher_w =
      reset_syscon_write_valid_w &&
      (reset_syscon_write_value_w[15:0] == 16'h3333);
  wire reset_syscon_terminal_w =
      reset_syscon_poweroff_w || reset_syscon_reboot_w ||
      reset_syscon_finisher_w;
  wire [`XLEN-1:0] reset_syscon_exit_code_w =
      reset_syscon_finisher_w
          ? {{(`XLEN-16){1'b0}}, reset_syscon_write_value_w[31:16]}
          : {`XLEN{1'b0}};

  NpcTop u_top (
    .clk(clk),
    .rst(rst),

    .psram_axi_arvalid_o(psram_axi_arvalid_w),
    .psram_axi_arready_i(psram_axi_arready_w),
    .psram_axi_araddr_o(psram_axi_araddr_w),
    .psram_axi_arsize_o(psram_axi_arsize_w),
    .psram_axi_arprot_o(psram_axi_arprot_w),
    .psram_axi_rvalid_i(psram_axi_rvalid_w),
    .psram_axi_rready_o(psram_axi_rready_w),
    .psram_axi_rdata_i(psram_axi_rdata_w),
    .psram_axi_rresp_i(psram_axi_rresp_w),
    .psram_axi_awvalid_o(psram_axi_awvalid_w),
    .psram_axi_awready_i(psram_axi_awready_w),
    .psram_axi_awaddr_o(psram_axi_awaddr_w),
    .psram_axi_awsize_o(psram_axi_awsize_w),
    .psram_axi_wvalid_o(psram_axi_wvalid_w),
    .psram_axi_wready_i(psram_axi_wready_w),
    .psram_axi_wdata_o(psram_axi_wdata_w),
    .psram_axi_wstrb_o(psram_axi_wstrb_w),
    .psram_axi_bvalid_i(psram_axi_bvalid_w),
    .psram_axi_bready_o(psram_axi_bready_w),
    .psram_axi_bresp_i(psram_axi_bresp_w),

    .sdram_axi_arvalid_o(sdram_axi_arvalid_w),
    .sdram_axi_arready_i(sdram_axi_arready_w),
    .sdram_axi_araddr_o(sdram_axi_araddr_w),
    .sdram_axi_arsize_o(sdram_axi_arsize_w),
    .sdram_axi_arprot_o(sdram_axi_arprot_w),
    .sdram_axi_rvalid_i(sdram_axi_rvalid_w),
    .sdram_axi_rready_o(sdram_axi_rready_w),
    .sdram_axi_rdata_i(sdram_axi_rdata_w),
    .sdram_axi_rresp_i(sdram_axi_rresp_w),
    .sdram_axi_awvalid_o(sdram_axi_awvalid_w),
    .sdram_axi_awready_i(sdram_axi_awready_w),
    .sdram_axi_awaddr_o(sdram_axi_awaddr_w),
    .sdram_axi_awsize_o(sdram_axi_awsize_w),
    .sdram_axi_wvalid_o(sdram_axi_wvalid_w),
    .sdram_axi_wready_i(sdram_axi_wready_w),
    .sdram_axi_wdata_o(sdram_axi_wdata_w),
    .sdram_axi_wstrb_o(sdram_axi_wstrb_w),
    .sdram_axi_bvalid_i(sdram_axi_bvalid_w),
    .sdram_axi_bready_o(sdram_axi_bready_w),
    .sdram_axi_bresp_i(sdram_axi_bresp_w),

    .legacy_mmio_axi_arvalid_o(legacy_mmio_axi_arvalid_w),
    .legacy_mmio_axi_arready_i(legacy_mmio_axi_arready_w),
    .legacy_mmio_axi_araddr_o(legacy_mmio_axi_araddr_w),
    .legacy_mmio_axi_arsize_o(legacy_mmio_axi_arsize_w),
    .legacy_mmio_axi_arprot_o(legacy_mmio_axi_arprot_w),
    .legacy_mmio_axi_rvalid_i(legacy_mmio_axi_rvalid_w),
    .legacy_mmio_axi_rready_o(legacy_mmio_axi_rready_w),
    .legacy_mmio_axi_rdata_i(legacy_mmio_axi_rdata_w),
    .legacy_mmio_axi_rresp_i(legacy_mmio_axi_rresp_w),
    .legacy_mmio_axi_awvalid_o(legacy_mmio_axi_awvalid_w),
    .legacy_mmio_axi_awready_i(legacy_mmio_axi_awready_w),
    .legacy_mmio_axi_awaddr_o(legacy_mmio_axi_awaddr_w),
    .legacy_mmio_axi_awsize_o(legacy_mmio_axi_awsize_w),
    .legacy_mmio_axi_wvalid_o(legacy_mmio_axi_wvalid_w),
    .legacy_mmio_axi_wready_i(legacy_mmio_axi_wready_w),
    .legacy_mmio_axi_wdata_o(legacy_mmio_axi_wdata_w),
    .legacy_mmio_axi_wstrb_o(legacy_mmio_axi_wstrb_w),
    .legacy_mmio_axi_bvalid_i(legacy_mmio_axi_bvalid_w),
    .legacy_mmio_axi_bready_o(legacy_mmio_axi_bready_w),
    .legacy_mmio_axi_bresp_i(legacy_mmio_axi_bresp_w),

    .virtio_blk_axi_arvalid_o(virtio_blk_axi_arvalid_w),
    .virtio_blk_axi_arready_i(virtio_blk_axi_arready_w),
    .virtio_blk_axi_araddr_o(virtio_blk_axi_araddr_w),
    .virtio_blk_axi_arsize_o(virtio_blk_axi_arsize_w),
    .virtio_blk_axi_arprot_o(virtio_blk_axi_arprot_w),
    .virtio_blk_axi_rvalid_i(virtio_blk_axi_rvalid_w),
    .virtio_blk_axi_rready_o(virtio_blk_axi_rready_w),
    .virtio_blk_axi_rdata_i(virtio_blk_axi_rdata_w),
    .virtio_blk_axi_rresp_i(virtio_blk_axi_rresp_w),
    .virtio_blk_axi_awvalid_o(virtio_blk_axi_awvalid_w),
    .virtio_blk_axi_awready_i(virtio_blk_axi_awready_w),
    .virtio_blk_axi_awaddr_o(virtio_blk_axi_awaddr_w),
    .virtio_blk_axi_awsize_o(virtio_blk_axi_awsize_w),
    .virtio_blk_axi_wvalid_o(virtio_blk_axi_wvalid_w),
    .virtio_blk_axi_wready_i(virtio_blk_axi_wready_w),
    .virtio_blk_axi_wdata_o(virtio_blk_axi_wdata_w),
    .virtio_blk_axi_wstrb_o(virtio_blk_axi_wstrb_w),
    .virtio_blk_axi_bvalid_i(virtio_blk_axi_bvalid_w),
    .virtio_blk_axi_bready_o(virtio_blk_axi_bready_w),
    .virtio_blk_axi_bresp_i(virtio_blk_axi_bresp_w),
    .virtio_blk_irq_i(virtio_blk_irq_w),
    .virtio_blk_dma_dcache_invalidate_all_i(
        virtio_blk_dma_dcache_invalidate_all_w),

    .uart_rx_valid_i(uart_rx_valid_q),
    .uart_rx_data_i(uart_rx_data_q),
    .uart_rx_ready_o(uart_rx_ready_w),
    .uart_tx_valid_o(uart_tx_valid_w),
    .uart_tx_data_o(uart_tx_data_w),
    .uart_access_valid_o(uart_access_valid_w),
    .uart_access_write_o(uart_access_write_w),
    .uart_access_addr_o(uart_access_addr_w),
    .uart_access_wdata_o(uart_access_wdata_w),
    .uart_access_wstrb_o(uart_access_wstrb_w),
    .uart_access_rdata_o(uart_access_rdata_w),
    .uart_irq_o(uart_irq_w),
    .plic_external_irq_o(plic_external_irq_w),
    .clint_mtime_o(clint_mtime_w),
    .reset_syscon_write_valid_o(reset_syscon_write_valid_w),
    .reset_syscon_write_value_o(reset_syscon_write_value_w),

    .commit0_valid_o(core_commit0_valid_w),
    .commit0_pc_o(core_commit0_pc_w),
    .commit0_inst_o(core_commit0_inst_w),
    .commit0_next_pc_o(core_commit0_next_pc_w),
    .commit0_rd_en_o(core_commit0_rd_en_w),
    .commit0_rd_addr_o(core_commit0_rd_addr_w),
    .commit0_rd_data_o(core_commit0_rd_data_w),
    .commit0_exception_o(core_commit0_exception_w),
    .commit0_write_o(core_commit0_write_w),
    .commit1_valid_o(core_commit1_valid_w),
    .commit1_pc_o(core_commit1_pc_w),
    .commit1_inst_o(core_commit1_inst_w),
    .commit1_next_pc_o(core_commit1_next_pc_w),
    .commit1_rd_en_o(core_commit1_rd_en_w),
    .commit1_rd_addr_o(core_commit1_rd_addr_w),
    .commit1_rd_data_o(core_commit1_rd_data_w),
    .commit1_exception_o(core_commit1_exception_w),
    .commit1_write_o(core_commit1_write_w),
    .trap_valid_o(core_trap_valid_w),
    .trap_cause_o(core_trap_cause_w),
    .trap_pc_o(core_trap_pc_w),
    .trap_tval_o(core_trap_tval_w),
    .exit_valid_o(core_exit_valid_w),
    .exit_is_ecall_o(core_exit_is_ecall_w),
    .exit_is_ebreak_o(core_exit_is_ebreak_w),
    .exit_code_o(core_exit_code_w),
    .exit_pc_o(core_exit_pc_w),
    .halted_o(core_halted_w),
    .debug_pc_o(debug_pc_o),
    .debug_state_o(debug_state_o),
    .retire_count_o(core_retire_count_w),
    .free_count_o(core_free_count_w),
    .rob_count_o(core_rob_count_w),
    .issue_count_o(core_issue_count_w)
  );

  wire unused_top_status_w =
      core_halted_w | core_commit0_write_w | core_commit1_write_w |
      (|core_retire_count_w) | (|core_free_count_w) |
      (|core_rob_count_w) | (|core_issue_count_w) |
      (|virtio_blk_axi_arsize_w) | (|virtio_blk_axi_arprot_w);

  assign debug_clint_mtime_o = clint_mtime_w;
`ifdef CONFIG_NPC_DEBUG_PORTS
  assign debug_ooo_satp_o = u_top.u_core.u_ooo_core.csr_satp_w;
  assign debug_ooo_flags_o = {
    23'd0,
    u_top.u_core.u_ooo_core.direct_frontend_flush_w,
    u_top.u_core.u_ooo_core.pending_replay_wait_w,
    u_top.u_core.u_ooo_core.drain_complete_w,
    u_top.u_core.u_ooo_core.csr_trap_ex_valid_w,
    u_top.u_core.u_ooo_core.pending_arch_trap_fire_w,
    (u_top.u_core.u_ooo_core.csr_satp_w[63:60] == 4'h8),
    u_top.u_core.u_ooo_core.csr_priv_mode_w,
    u_top.u_core.u_ooo_core.dispatch0_system_w,
    u_top.u_core.u_ooo_core.head0_csr_illegal_w,
    u_top.u_core.u_ooo_core.dispatch0_arch_trap_w,
    u_top.u_core.u_ooo_core.head_fetch_fault0_w,
    u_top.u_core.u_ooo_core.head_resp0_w,
    {1'b0, u_top.u_core.u_ooo_core.pending_trap_cause_q},
    u_top.u_core.u_ooo_core.fifo_has_packet_w,
    u_top.u_core.u_ooo_core.can_run_w,
    u_top.u_core.u_ooo_core.pending_system_csr_commit_w,
    u_top.u_core.u_ooo_core.system_csr_dispatch_fire_w,
    u_top.u_core.u_ooo_core.system_csr_dispatch_valid_w,
    u_top.u_core.u_ooo_core.dispatch0_ready_w,
    u_top.u_core.u_ooo_core.backend_drained_w,
    u_top.u_core.u_ooo_core.backend_drained_q,
    u_top.u_core.u_ooo_core.csr_irq_pending_w,
    u_top.u_core.u_ooo_core.pending_system_dispatched_q,
    u_top.u_core.u_ooo_core.pending_system_csr_q,
    u_top.u_core.u_ooo_core.pending_system_irq_q,
    u_top.u_core.u_ooo_core.pending_system_q,
    u_top.u_core.u_ooo_core.pending_arch_trap_q,
    u_top.u_core.u_ooo_core.pending_mem_q,
    u_top.u_core.u_ooo_core.pending_jump_q,
    u_top.u_core.u_ooo_core.pending_branch_q,
    u_top.u_core.u_ooo_core.pending_exit_q,
    u_top.u_core.u_ooo_core.orphan_stop_pending_w,
    u_top.u_core.u_ooo_core.stop_pending_owner_w,
    u_top.u_core.u_ooo_core.stop_pending_q
  };
  assign debug_bus_flags_o = {
    9'd0,
    u_top.u_bus.u_xbar.rd_active_q,
    u_top.u_bus.u_xbar.rd_resp_valid_q,
    u_top.u_bus.u_xbar.rd_master_busy_q,
    u_top.lsu_axi_bready_w,
    u_top.lsu_axi_bvalid_w,
    u_top.lsu_axi_wready_w,
    u_top.lsu_axi_wvalid_w,
    u_top.lsu_axi_awready_w,
    u_top.lsu_axi_awvalid_w,
    u_top.lsu_axi_rready_w,
    u_top.lsu_axi_rvalid_w,
    u_top.lsu_axi_arready_w,
    u_top.lsu_axi_arvalid_w,
    u_top.ifu_axi_rready_w,
    u_top.ifu_axi_rvalid_w,
    u_top.ifu_axi_arready_w,
    u_top.ifu_axi_arvalid_w,
    u_top.u_core.u_ooo_mem_bridge.drop_rsp_q,
    u_top.u_core.u_ooo_mem_bridge.drop_rsp_q,  // 修悬空引用: active_port_q 已删(刀M时代)
    u_top.u_core.u_ooo_mem_bridge.write_q,
    u_top.u_core.u_ooo_mem_bridge.state_q,
    u_top.u_core.u_ooo_fetch_bridge.walk_second_q,
    u_top.u_core.u_ooo_fetch_bridge.walk_level_q,
    u_top.u_core.u_ooo_fetch_bridge.paging_q,
    u_top.u_core.u_ooo_fetch_bridge.state_q,
    u_top.u_core.u_ooo_core.discard_fetch_rsp_q,
    u_top.u_core.u_ooo_core.outstanding_valid_q,
    u_top.u_core.u_ooo_core.fetch_rsp_ready_o,
    u_top.u_core.u_ooo_core.fetch_rsp_valid_i,
    u_top.u_core.u_ooo_core.fetch_req_ready_i,
    u_top.u_core.u_ooo_core.fetch_req_valid_o
  };
  assign debug_bus2_flags_o = {
    15'd0,
    u_top.u_bus.u_xbar.rd_ar_sent_q,  // AXI4化S2: rd_drop_q 已删,占位换 ar_sent
    u_top.u_bus.u_xbar.rd_ar_sent_q,
    u_top.u_bus.u_xbar.rd_owner_q[AXI_S_DEFAULT],
    u_top.u_bus.u_xbar.rd_owner_q[AXI_S_RESET_SYSCON],
    u_top.u_bus.u_xbar.rd_owner_q[AXI_S_UART],
    u_top.u_bus.u_xbar.rd_owner_q[AXI_S_CLINT],
    u_top.bus_axi_rready_w[AXI_S_RESET_SYSCON],
    u_top.bus_axi_rvalid_w[AXI_S_RESET_SYSCON],
    u_top.bus_axi_arready_w[AXI_S_RESET_SYSCON],
    u_top.bus_axi_arvalid_w[AXI_S_RESET_SYSCON],
    u_top.u_core.u_ooo_mem_bridge.flush_i,   // AXI4化S2: abort 边带已删,探针改引等价 flush 源
    u_top.u_core.u_ooo_fetch_bridge.mmu_flush_i,
    u_top.u_core.u_ooo_mem_bridge.flush_i,
    u_top.u_core.u_ooo_fetch_bridge.mmu_flush_i
  };
  assign debug_fetch_addr_o = u_top.u_core.u_ooo_fetch_bridge.pc_q;
  assign debug_mem_addr_o = u_top.u_core.u_ooo_mem_bridge.addr_q;
  assign debug_fetch_pte_addr_o = u_top.u_core.u_ooo_fetch_bridge.debug_last_pte_addr_q;
  assign debug_fetch_pte_o = u_top.u_core.u_ooo_fetch_bridge.debug_last_pte_q;
  assign debug_fetch_pte_meta_o = {
    61'd0,
    u_top.u_core.u_ooo_fetch_bridge.debug_last_pte_second_q,
    u_top.u_core.u_ooo_fetch_bridge.debug_last_pte_level_q
  };
`else
  assign debug_ooo_satp_o = 64'd0;
  assign debug_ooo_flags_o = 64'd0;
  assign debug_bus_flags_o = 64'd0;
  assign debug_bus2_flags_o = 64'd0;
  assign debug_fetch_addr_o = 64'd0;
  assign debug_mem_addr_o = 64'd0;
  assign debug_fetch_pte_addr_o = 64'd0;
  assign debug_fetch_pte_o = 64'd0;
  assign debug_fetch_pte_meta_o = 64'd0;
`endif

  AxiVirtioBlk #(
    .ADDR_W(`XLEN),
    .DATA_W(`XLEN),
    .STRB_W(`STRB_W)
  ) u_virtio_blk_axi (
    .clk(clk),
    .rst(rst),
    .s_axi_arvalid_i(virtio_blk_axi_arvalid_w),
    .s_axi_arready_o(virtio_blk_axi_arready_w),
    .s_axi_araddr_i(virtio_blk_axi_araddr_w),
    .s_axi_arsize_i(virtio_blk_axi_arsize_w),
    .s_axi_rvalid_o(virtio_blk_axi_rvalid_w),
    .s_axi_rready_i(virtio_blk_axi_rready_w),
    .s_axi_rdata_o(virtio_blk_axi_rdata_w),
    .s_axi_rresp_o(virtio_blk_axi_rresp_w),
    .s_axi_awvalid_i(virtio_blk_axi_awvalid_w),
    .s_axi_awready_o(virtio_blk_axi_awready_w),
    .s_axi_awaddr_i(virtio_blk_axi_awaddr_w),
    .s_axi_awsize_i(virtio_blk_axi_awsize_w),
    .s_axi_wvalid_i(virtio_blk_axi_wvalid_w),
    .s_axi_wready_o(virtio_blk_axi_wready_w),
    .s_axi_wdata_i(virtio_blk_axi_wdata_w),
    .s_axi_wstrb_i(virtio_blk_axi_wstrb_w),
    .s_axi_bvalid_o(virtio_blk_axi_bvalid_w),
    .s_axi_bready_i(virtio_blk_axi_bready_w),
    .s_axi_bresp_o(virtio_blk_axi_bresp_w),
    .irq_o(virtio_blk_irq_w),
    .dma_dcache_invalidate_all_o(
        virtio_blk_dma_dcache_invalidate_all_w)
  );

  AxiDpiSlave u_psram_slave (
    .clk(clk),
    .rst(rst),
    .s_axi_arvalid_i(psram_axi_arvalid_w),
    .s_axi_arready_o(psram_axi_arready_w),
    .s_axi_araddr_i(psram_axi_araddr_w),
    .s_axi_arsize_i(psram_axi_arsize_w),
    .s_axi_arprot_i(psram_axi_arprot_w),
    .s_axi_rvalid_o(psram_axi_rvalid_w),
    .s_axi_rready_i(psram_axi_rready_w),
    .s_axi_rdata_o(psram_axi_rdata_w),
    .s_axi_rresp_o(psram_axi_rresp_w),
    .s_axi_awvalid_i(psram_axi_awvalid_w),
    .s_axi_awready_o(psram_axi_awready_w),
    .s_axi_awaddr_i(psram_axi_awaddr_w),
    .s_axi_awsize_i(psram_axi_awsize_w),
    .s_axi_wvalid_i(psram_axi_wvalid_w),
    .s_axi_wready_o(psram_axi_wready_w),
    .s_axi_wdata_i(psram_axi_wdata_w),
    .s_axi_wstrb_i(psram_axi_wstrb_w),
    .s_axi_bvalid_o(psram_axi_bvalid_w),
    .s_axi_bready_i(psram_axi_bready_w),
    .s_axi_bresp_o(psram_axi_bresp_w)
  );

  AxiDpiSlave u_sdram_slave (
    .clk(clk),
    .rst(rst),
    .s_axi_arvalid_i(sdram_axi_arvalid_w),
    .s_axi_arready_o(sdram_axi_arready_w),
    .s_axi_araddr_i(sdram_axi_araddr_w),
    .s_axi_arsize_i(sdram_axi_arsize_w),
    .s_axi_arprot_i(sdram_axi_arprot_w),
    .s_axi_rvalid_o(sdram_axi_rvalid_w),
    .s_axi_rready_i(sdram_axi_rready_w),
    .s_axi_rdata_o(sdram_axi_rdata_w),
    .s_axi_rresp_o(sdram_axi_rresp_w),
    .s_axi_awvalid_i(sdram_axi_awvalid_w),
    .s_axi_awready_o(sdram_axi_awready_w),
    .s_axi_awaddr_i(sdram_axi_awaddr_w),
    .s_axi_awsize_i(sdram_axi_awsize_w),
    .s_axi_wvalid_i(sdram_axi_wvalid_w),
    .s_axi_wready_o(sdram_axi_wready_w),
    .s_axi_wdata_i(sdram_axi_wdata_w),
    .s_axi_wstrb_i(sdram_axi_wstrb_w),
    .s_axi_bvalid_o(sdram_axi_bvalid_w),
    .s_axi_bready_i(sdram_axi_bready_w),
    .s_axi_bresp_o(sdram_axi_bresp_w)
  );

  AxiDpiSlave u_legacy_mmio_slave (
    .clk(clk),
    .rst(rst),
    .s_axi_arvalid_i(legacy_mmio_axi_arvalid_w),
    .s_axi_arready_o(legacy_mmio_axi_arready_w),
    .s_axi_araddr_i(legacy_mmio_axi_araddr_w),
    .s_axi_arsize_i(legacy_mmio_axi_arsize_w),
    .s_axi_arprot_i(legacy_mmio_axi_arprot_w),
    .s_axi_rvalid_o(legacy_mmio_axi_rvalid_w),
    .s_axi_rready_i(legacy_mmio_axi_rready_w),
    .s_axi_rdata_o(legacy_mmio_axi_rdata_w),
    .s_axi_rresp_o(legacy_mmio_axi_rresp_w),
    .s_axi_awvalid_i(legacy_mmio_axi_awvalid_w),
    .s_axi_awready_o(legacy_mmio_axi_awready_w),
    .s_axi_awaddr_i(legacy_mmio_axi_awaddr_w),
    .s_axi_awsize_i(legacy_mmio_axi_awsize_w),
    .s_axi_wvalid_i(legacy_mmio_axi_wvalid_w),
    .s_axi_wready_o(legacy_mmio_axi_wready_w),
    .s_axi_wdata_i(legacy_mmio_axi_wdata_w),
    .s_axi_wstrb_i(legacy_mmio_axi_wstrb_w),
    .s_axi_bvalid_o(legacy_mmio_axi_bvalid_w),
    .s_axi_bready_i(legacy_mmio_axi_bready_w),
    .s_axi_bresp_o(legacy_mmio_axi_bresp_w)
  );

`ifdef CONFIG_NPC_SIM_STATS
  // RV64 只保留 OoO/superscalar core，cache/BPU/pipe 统计均从 OoO bridge/core 只读观察。
  // SRAM 同步读(2026-07-08)后 hit 在判决拍才有效：access 打一拍与判决拍对齐。
  // 【P5 刀 M】mem 侧统计打拍源从 mem0_req_fire_w 改为桥内 stage_advance_w:
  // fire 拍只进寄存站, dcache lookup 在 advance 拍发射、判决在其次拍——沿用
  // fire 源会使 hit 配对错 1 拍; access 口径=advance(真正消费翻译/dcache 资源
  // 的拍), flush 清掉的寄存站项不计。fetch 侧不变。
  // fetch 侧 fire 后必进 S_LOOKUP 判决；mem 侧 fault/translate-miss 的 read 不经判决,
  // cache hit 输出带 pend 门控恒 0 → 记 miss,与旧"fault 亦计 miss"语义一致。
  reg sim_icache_access_q;
  reg sim_dcache_read_access_q;
  always @(posedge clk) begin
    sim_icache_access_q <= u_top.u_core.u_ooo_fetch_bridge.fetch_req_fire_w;
    sim_dcache_read_access_q <=
        u_top.u_core.u_ooo_mem_bridge.stage_advance_w &&
        !u_top.u_core.u_ooo_mem_bridge.req_write_w;
  end
  assign sim_icache_access_w = sim_icache_access_q;
  assign sim_icache_hit_w = sim_icache_access_q &&
                            u_top.u_core.u_ooo_fetch_bridge.cache_hit_w;
  assign sim_icache_miss_w = sim_icache_access_q &&
                             !u_top.u_core.u_ooo_fetch_bridge.cache_hit_w;
  assign sim_dcache_access_w =
      u_top.u_core.u_ooo_mem_bridge.stage_advance_w;
  assign sim_dcache_store_access_w =
      sim_dcache_access_w && u_top.u_core.u_ooo_mem_bridge.req_write_w;
  assign sim_dcache_hit_w =
      sim_dcache_read_access_q &&
      u_top.u_core.u_ooo_mem_bridge.dcache_lookup_hit_final_w;
  assign sim_dcache_miss_w =
      sim_dcache_read_access_q &&
      !u_top.u_core.u_ooo_mem_bridge.dcache_lookup_hit_final_w;
  assign sim_dcache_writeback_w = 1'b0;
  assign sim_dcache_write_through_w = 1'b0;
  assign sim_control_event_w = 1'b0;
  assign sim_bpu_ret_resolve_w = 1'b0;
  assign sim_bpu_pred_taken_w = 1'b0;
  assign sim_bpu_resolve_correct_w = 1'b0;
  wire sim_ooo_pending_jalr_ret_w =
      u_top.u_core.u_ooo_core.pending_jump_q &&
      u_top.u_core.u_ooo_core.pending_jump_jalr_q &&
      (u_top.u_core.u_ooo_core.pending_jump_inst_q[11:7] == 5'd0) &&
      sim_is_link_reg(u_top.u_core.u_ooo_core.pending_jump_rs1_q) &&
      (u_top.u_core.u_ooo_core.pending_jump_imm_q == {`XLEN{1'b0}});
  wire sim_ooo_pending_jalr_lookup_w =
      u_top.u_core.u_ooo_core.pending_jump_resolve_ready_w &&
      u_top.u_core.u_ooo_core.pending_jump_jalr_q &&
      !u_top.u_core.u_ooo_core.pending_jump_misaligned_w;
  wire sim_ooo_direct_ras_lookup_w =
      u_top.u_core.u_ooo_core.direct_ret0_fire_w ||
      u_top.u_core.u_ooo_core.direct_ret1_fire_w ||
      u_top.u_core.u_ooo_core.direct_branch0_lane1_ret_w;
  wire sim_ooo_pending_ras_lookup_w =
      sim_ooo_pending_jalr_lookup_w && sim_ooo_pending_jalr_ret_w;
  wire sim_ooo_ras_lookup_event_w =
      sim_ooo_direct_ras_lookup_w || sim_ooo_pending_ras_lookup_w;
  wire sim_ooo_ras_hit_w =
      sim_ooo_direct_ras_lookup_w ||
      (sim_ooo_pending_ras_lookup_w && !u_top.u_core.u_ooo_core.ras_empty_w);
  wire sim_ooo_btb_lookup_event_w =
      sim_ooo_pending_jalr_lookup_w &&
      !(sim_ooo_pending_jalr_ret_w && !u_top.u_core.u_ooo_core.ras_empty_w);
  wire sim_ooo_ras_overflow_event_w =
      (u_top.u_core.u_ooo_core.direct_jal_call_w ||
       u_top.u_core.u_ooo_core.pending_jump_call_fire_w) &&
      u_top.u_core.u_ooo_core.ras_full_w;
  assign sim_bpu_lookup_event_w =
      u_top.u_core.u_ooo_core.branch_bpu_lookup_event_w ||
      sim_ooo_btb_lookup_event_w ||
      sim_ooo_ras_lookup_event_w ||
      sim_ooo_ras_overflow_event_w;
  // OoO 统计只在仿真顶层旁路观察已有信号，不回馈任何 ready/valid 或提交路径。
  wire [1:0] sim_ooo_execute_count_w =
      {1'b0, u_top.u_core.u_ooo_core.execute0_valid_unused_w} +
      {1'b0, u_top.u_core.u_ooo_core.execute1_valid_unused_w};
  wire [1:0] sim_ooo_dispatch_count_w =
      {1'b0, u_top.u_core.u_ooo_core.core_dispatch0_fire_w} +
      {1'b0, (u_top.u_core.u_ooo_core.core_dispatch1_valid_w &&
              u_top.u_core.u_ooo_core.dispatch1_ready_w)};
  // 1M-cycle 性能桶保持只读旁路采样；同一 cycle 可同时归入多个桶。
  wire sim_ooo_fetch_busy_w =
      u_top.u_core.u_ooo_core.fetch_req_valid_o ||
      u_top.u_core.u_ooo_core.outstanding_valid_q ||
      (u_top.u_core.u_ooo_fetch_bridge.state_q != 4'd0);
  wire sim_ooo_mem_busy_w =
      u_top.u_core.u_ooo_core.pending_mem_q ||
      (u_top.u_core.u_ooo_mem_bridge.state_q != 4'd0) ||
      // 【刀 M】寄存站占用也算 mem busy(FSM idle+站内保持的拍, 如 RMW hold)
      u_top.u_core.u_ooo_mem_bridge.stg_valid_q ||
      u_top.u_core.u_ooo_mem_bridge.mem0_req_fire_w;
  wire sim_ooo_axi_wait_w =
      (u_top.ifu_axi_arvalid_w && !u_top.ifu_axi_arready_w) ||
      (u_top.ifu_axi_rready_w && !u_top.ifu_axi_rvalid_w) ||
      (u_top.lsu_axi_arvalid_w && !u_top.lsu_axi_arready_w) ||
      (u_top.lsu_axi_rready_w && !u_top.lsu_axi_rvalid_w) ||
      (u_top.lsu_axi_awvalid_w && !u_top.lsu_axi_awready_w) ||
      (u_top.lsu_axi_wvalid_w && !u_top.lsu_axi_wready_w) ||
      (u_top.lsu_axi_bready_w && !u_top.lsu_axi_bvalid_w);
  wire sim_ooo_hazard_busy_w =
      u_top.u_core.u_ooo_core.core_commit1_block_w ||
      (u_top.u_core.u_ooo_core.fifo_has_packet_w &&
       u_top.u_core.u_ooo_core.can_run_w &&
       (u_top.u_core.u_ooo_core.dispatch_unsupported_w ||
        u_top.u_core.u_ooo_core.branch_spec_dispatch_block_w ||
        (u_top.u_core.u_ooo_core.dispatch_valid_w &&
         (!u_top.u_core.u_ooo_core.dispatch0_ready_w ||
          !u_top.u_core.u_ooo_core.dispatch1_ready_w))));
  // 【B2 S2 观测口迁移】direct fire 家族不再含分支(fire 物理死化), taken 预测改为
  // fetch resp 拍改流(fetch_pred_taken_redirect: 包入队且预测 taken, 断融合付 1 拍)
  // ——事件拍口径随迁, 避免收益数字失真(桶语义=控制流打断顺序取指的拍)。
  wire sim_ooo_branch_flush_w =
      u_top.u_core.u_ooo_core.direct_frontend_flush_w ||
      u_top.u_core.u_ooo_core.u_frontend.fetch_pred_taken_redirect_w ||
      u_top.u_core.u_ooo_core.branch_resolve_redirect_w ||
      u_top.u_core.u_ooo_core.branch_spec_redirect_w ||
      u_top.u_core.u_ooo_core.branch_resolve_untracked_redirect_w ||
      u_top.u_core.u_ooo_core.pending_jump_redirect_after_dispatch_w ||
      u_top.u_core.u_ooo_core.pending_jump_nolink_commit_w ||
      u_top.u_core.u_ooo_core.pending_branch_commit_resolve_w;
  wire sim_ooo_exception_busy_w =
      u_top.u_core.u_ooo_core.pending_arch_trap_q ||
      u_top.u_core.u_ooo_core.trap_valid_q ||
      u_top.u_core.u_ooo_core.core_trap_flush_q ||
      u_top.u_core.u_ooo_core.pending_system_ecall_trap_w ||
      u_top.u_core.u_ooo_core.pending_system_irq_q ||
      u_top.u_core.u_ooo_core.csr_trap_mem_valid_w ||
      u_top.u_core.u_ooo_core.csr_trap_ex_valid_w ||
      u_top.u_core.u_ooo_core.csr_trap_irq_valid_w;
  wire unused_ooo_sim_stat_w =
      sim_icache_access_w | sim_icache_hit_w | sim_icache_miss_w |
      sim_dcache_access_w | sim_dcache_hit_w | sim_dcache_miss_w |
      sim_dcache_store_access_w | sim_dcache_writeback_w |
      sim_dcache_write_through_w | sim_control_event_w |
      sim_bpu_lookup_event_w | sim_bpu_ret_resolve_w |
      sim_bpu_pred_taken_w | sim_bpu_resolve_correct_w |
      u_top.u_core.u_ooo_core.branch_bpu_update_valid_w |
      u_top.u_core.u_ooo_core.branch_bpu_update_correct_w |
      sim_ooo_pending_jalr_ret_w | sim_ooo_pending_jalr_lookup_w |
      sim_ooo_direct_ras_lookup_w | sim_ooo_pending_ras_lookup_w |
      sim_ooo_ras_lookup_event_w | sim_ooo_ras_hit_w |
      sim_ooo_btb_lookup_event_w | sim_ooo_ras_overflow_event_w |
      sim_ooo_fetch_busy_w | sim_ooo_mem_busy_w | sim_ooo_axi_wait_w |
      sim_ooo_hazard_busy_w | sim_ooo_branch_flush_w |
      sim_ooo_exception_busy_w |
      (|sim_ooo_execute_count_w) | (|sim_ooo_dispatch_count_w);
`endif

  localparam int UART_RX_POLL_SHIFT = `CONFIG_NPC_UART_RX_POLL_SHIFT;
  localparam logic [31:0] UART_RX_POLL_MASK =
      (UART_RX_POLL_SHIFT <= 0) ? 32'd0 :
      (UART_RX_POLL_SHIFT >= 32) ? 32'hffff_ffff :
      ((32'd1 << UART_RX_POLL_SHIFT) - 32'd1);
  wire uart_rx_poll_due_w =
      (UART_RX_POLL_MASK == 32'd0) ||
      ((uart_rx_poll_q & UART_RX_POLL_MASK) == 32'd0);

  always_ff @(posedge clk) begin
    int unsigned uart_rx_data_v;
    int uart_rx_has_data_v;

    if (rst) begin
      uart_rx_valid_q <= 1'b0;
      uart_rx_data_q <= 8'h00;
      uart_rx_poll_q <= 32'd0;
    end else begin
      uart_rx_poll_q <= uart_rx_poll_q + 32'd1;
      if (uart_rx_valid_q && !uart_rx_ready_w) begin
        uart_rx_valid_q <= uart_rx_valid_q;
        uart_rx_data_q <= uart_rx_data_q;
      end else if (uart_rx_poll_due_w) begin
        uart_rx_has_data_v = npc_uart_rx_pop(uart_rx_data_v);
        uart_rx_valid_q <= (uart_rx_has_data_v != 0);
        uart_rx_data_q <= uart_rx_data_v[7:0];
      end else begin
        uart_rx_valid_q <= 1'b0;
        uart_rx_data_q <= 8'h00;
      end
    end
  end

  // 全状态 difftest: XMR 从 CsrFile 汇聚 CSR+priv 到 23 槽快照(索引与 difftest.h/NEMU dut.c 一致)。
  // 阶段1 比较 [0,17): 确定性 CSR + priv; 17..22(mie/mip/mcycle/minstret/fflags/frm)先填不比。
  wire [63:0] diff_csr_snap [0:22];
  assign diff_csr_snap[0]  = u_top.u_core.u_csr_file.csr_mstatus_q;
  assign diff_csr_snap[1]  = u_top.u_core.u_csr_file.csr_mepc_q;
  assign diff_csr_snap[2]  = u_top.u_core.u_csr_file.csr_mcause_q;
  assign diff_csr_snap[3]  = u_top.u_core.u_csr_file.csr_mtvec_q;
  assign diff_csr_snap[4]  = u_top.u_core.u_csr_file.csr_mtval_q;
  assign diff_csr_snap[5]  = u_top.u_core.u_csr_file.csr_mscratch_q;
  assign diff_csr_snap[6]  = u_top.u_core.u_csr_file.csr_sepc_q;
  assign diff_csr_snap[7]  = u_top.u_core.u_csr_file.csr_scause_q;
  assign diff_csr_snap[8]  = u_top.u_core.u_csr_file.csr_stvec_q;
  assign diff_csr_snap[9]  = u_top.u_core.u_csr_file.csr_stval_q;
  assign diff_csr_snap[10] = u_top.u_core.u_csr_file.csr_sscratch_q;
  assign diff_csr_snap[11] = u_top.u_core.u_csr_file.csr_medeleg_q;
  assign diff_csr_snap[12] = u_top.u_core.u_csr_file.csr_mideleg_q;
  assign diff_csr_snap[13] = u_top.u_core.u_csr_file.csr_satp_q;
  assign diff_csr_snap[14] = u_top.u_core.u_csr_file.csr_mcounteren_q;
  assign diff_csr_snap[15] = u_top.u_core.u_csr_file.csr_scounteren_q;
  assign diff_csr_snap[16] = {62'b0, u_top.u_core.u_csr_file.priv_mode_q};
  assign diff_csr_snap[17] = u_top.u_core.u_csr_file.csr_mie_q;
  assign diff_csr_snap[18] = u_top.u_core.u_csr_file.csr_mip_visible_w;
  assign diff_csr_snap[19] = u_top.u_core.u_csr_file.csr_mcycle_q;
  assign diff_csr_snap[20] = u_top.u_core.u_csr_file.csr_minstret_q;
  assign diff_csr_snap[21] = {59'b0, u_top.u_core.u_csr_file.csr_fflags_q};
  assign diff_csr_snap[22] = {61'b0, u_top.u_core.u_csr_file.csr_frm_q};

  // 阶段2: XMR 汇聚 arch FPR(32×64bit)。深路径到 OooFpBackend 的 arch_fprs_flat_w。
  wire [63:0] diff_fpr_snap [0:31];
  genvar fpr_gi;
  generate
    for (fpr_gi = 0; fpr_gi < 32; fpr_gi = fpr_gi + 1) begin : g_diff_fpr_snap
      assign diff_fpr_snap[fpr_gi] =
        u_top.u_core.u_ooo_core.u_execute_backend.u_core_slice.u_decode_backend.u_int_backend.u_fp_backend.arch_fprs_flat_w[fpr_gi*64 +: 64];
    end
  endgenerate

  // 仿真事件仍集中在顶层；真实 PMEM/MMIO 请求已经下沉到 AxiDpiSlave。
  always_ff @(posedge clk) begin
    if (rst) begin
      exit_reported_q <= 1'b0;
      uart_irq_prev_q <= 1'b0;
      plic_irq_prev_q <= 1'b0;
    end else begin
      if ((uart_irq_w != uart_irq_prev_q) ||
          (plic_external_irq_w != plic_irq_prev_q)) begin
        npc_irq_event(
          uart_irq_w ? 32'd1 : 32'd0,
          plic_external_irq_w ? 32'd1 : 32'd0
        );
      end
      uart_irq_prev_q <= uart_irq_w;
      plic_irq_prev_q <= plic_external_irq_w;

      // difftest: 非 pmem 的 load(MMIO 读, 如 goldfish timer)返回值依赖设备
      // 状态, ref 无法对齐 → 挂起 skip_ref(uart 同款粗粒度; 该 load 的
      // difftest_step 消费并以 dut 状态覆盖 ref)。
      if (u_top.u_core.u_ooo_mem_bridge.mem0_rsp_valid_o &&
          u_top.u_core.u_ooo_mem_bridge.mem0_rsp_ready_i &&
          !u_top.u_core.u_ooo_mem_bridge.write_q &&
          ((u_top.u_core.u_ooo_mem_bridge.paddr_q & `NPC_AXI_PMEM_MASK)
             != `NPC_AXI_PMEM_BASE) &&
          ((u_top.u_core.u_ooo_mem_bridge.paddr_q & 64'hffff_f000)
             != 64'h1000_0000)) begin
        npc_mmio_load_event();
      end

      if (uart_access_valid_w) begin
        // UART 已从 DPI 大从设备拆出；这里补回仿真侧输出和 difftest MMIO skip。
        npc_uart_event(
          uart_access_write_w ? 32'd1 : 32'd0,
          uart_tx_valid_w ? 32'd1 : 32'd0,
          {24'd0, uart_tx_data_w},
          {20'd0, uart_access_addr_w},
          uart_access_wdata_w,
          {{(32-`STRB_W){1'b0}}, uart_access_wstrb_w},
          uart_access_rdata_w
        );
      end

      // 全状态 difftest: 每拍把 CSR+priv 快照送宿主(commit 处理时快照进 event)。
      npc_arch_csr_event(
        diff_csr_snap[0],  diff_csr_snap[1],  diff_csr_snap[2],  diff_csr_snap[3],
        diff_csr_snap[4],  diff_csr_snap[5],  diff_csr_snap[6],  diff_csr_snap[7],
        diff_csr_snap[8],  diff_csr_snap[9],  diff_csr_snap[10], diff_csr_snap[11],
        diff_csr_snap[12], diff_csr_snap[13], diff_csr_snap[14], diff_csr_snap[15],
        diff_csr_snap[16], diff_csr_snap[17], diff_csr_snap[18], diff_csr_snap[19],
        diff_csr_snap[20], diff_csr_snap[21], diff_csr_snap[22]);
      npc_arch_fpr_event(
        diff_fpr_snap[0],  diff_fpr_snap[1],  diff_fpr_snap[2],  diff_fpr_snap[3],
        diff_fpr_snap[4],  diff_fpr_snap[5],  diff_fpr_snap[6],  diff_fpr_snap[7],
        diff_fpr_snap[8],  diff_fpr_snap[9],  diff_fpr_snap[10], diff_fpr_snap[11],
        diff_fpr_snap[12], diff_fpr_snap[13], diff_fpr_snap[14], diff_fpr_snap[15],
        diff_fpr_snap[16], diff_fpr_snap[17], diff_fpr_snap[18], diff_fpr_snap[19],
        diff_fpr_snap[20], diff_fpr_snap[21], diff_fpr_snap[22], diff_fpr_snap[23],
        diff_fpr_snap[24], diff_fpr_snap[25], diff_fpr_snap[26], diff_fpr_snap[27],
        diff_fpr_snap[28], diff_fpr_snap[29], diff_fpr_snap[30], diff_fpr_snap[31]);

      // commit/trap/exit 只作为仿真事件推给宿主侧，避免把宽调试总线做成 Verilator 顶层 IO。
      if (core_commit0_valid_w && !core_commit0_exception_w) begin
        npc_commit_event(
          core_commit0_pc_w,
          core_commit0_inst_w,
          core_commit0_next_pc_w,
          core_commit0_rd_en_w ? 32'd1 : 32'd0,
          {{(32-`REG_ADDR_W){1'b0}}, core_commit0_rd_addr_w},
          core_commit0_rd_data_w,
          u_top.u_core.u_ooo_core.core_commit0_is_fp_rd_w ? 32'd1 : 32'd0
        );
      end

      if (core_commit1_valid_w && !core_commit1_exception_w) begin
        npc_commit_event(
          core_commit1_pc_w,
          core_commit1_inst_w,
          core_commit1_next_pc_w,
          core_commit1_rd_en_w ? 32'd1 : 32'd0,
          {{(32-`REG_ADDR_W){1'b0}}, core_commit1_rd_addr_w},
          core_commit1_rd_data_w,
          u_top.u_core.u_ooo_core.core_commit1_is_fp_rd_w ? 32'd1 : 32'd0
        );
      end

`ifdef CONFIG_NPC_BRANCH_STATS
      if (u_top.u_core.u_ooo_core.branch_bpu_update_valid_w) begin
        npc_bpu_resolve_event(
          32'd1,
          u_top.u_core.u_ooo_core.branch_bpu_update_pc_w[31:0],
          32'd0,
          32'd0,
          32'd0,
          u_top.u_core.u_ooo_core.branch_bpu_update_pred_taken_w ? 32'd1 : 32'd0,
          u_top.u_core.u_ooo_core.branch_bpu_update_taken_w ? 32'd1 : 32'd0,
          u_top.u_core.u_ooo_core.branch_bpu_update_correct_w ? 32'd1 : 32'd0
        );
      end

      if (sim_bpu_lookup_event_w) begin
        // OoO 侧 BPU 仍不进入端口 ABI；仿真顶层只读观察预测表 lookup 结果。
        // branch 走 OoO gshare/local，普通非 return JALR 走 OoO JALR BTB，return 走 OoO RAS。
        npc_bpu_lookup_event(
          u_top.u_core.u_ooo_core.branch_bpu_lookup_event_w ? 32'd1 : 32'd0,
          sim_ooo_btb_lookup_event_w ? 32'd1 : 32'd0,
          sim_ooo_ras_lookup_event_w ? 32'd1 : 32'd0,
          u_top.u_core.u_ooo_core.pending_jump_jalr_btb_hit_w ? 32'd1 : 32'd0,
          u_top.u_core.u_ooo_core.branch_bpu_lookup_bht_valid_w ? 32'd1 : 32'd0,
          sim_ooo_ras_lookup_event_w ? 32'd1 : 32'd0,
          sim_ooo_ras_hit_w ? 32'd1 : 32'd0,
          sim_ooo_ras_overflow_event_w ? 32'd1 : 32'd0
        );
      end
`endif

`ifdef CONFIG_NPC_CACHE_STATS
      if (sim_icache_access_w) begin
        npc_icache_event(
          32'd1,
          sim_icache_hit_w ? 32'd1 : 32'd0,
          sim_icache_miss_w ? 32'd1 : 32'd0
        );
      end

      // SRAM 同步读后 hit/miss 在判决拍(fire 次拍)才有效：access/store 仍在
      // fire 拍计数，hit/miss 改在判决拍单独上报(C 侧为累加语义，两次调用等价)。
      if (sim_dcache_access_w) begin
        npc_dcache_event(
          32'd1,
          32'd0,
          32'd0,
          32'd0,
          sim_dcache_write_through_w ? 32'd1 : 32'd0,
          sim_dcache_store_access_w ? 32'd1 : 32'd0
        );
      end
      if (sim_dcache_read_access_q) begin
        npc_dcache_event(
          32'd0,
          sim_dcache_hit_w ? 32'd1 : 32'd0,
          sim_dcache_miss_w ? 32'd1 : 32'd0,
          32'd0,
          32'd0,
          32'd0
        );
      end

      if (sim_dcache_writeback_w) begin
        npc_dcache_event(32'd0, 32'd0, 32'd0, 32'd1, 32'd0, 32'd0);
      end
`endif

`ifdef CONFIG_NPC_OOO_STATS
      npc_ooo_cycle_event(
        {30'd0, core_retire_count_w},
        {30'd0, sim_ooo_execute_count_w},
        {30'd0, sim_ooo_dispatch_count_w},
        u_top.u_core.u_ooo_core.fetch_req_valid_o ? 32'd1 : 32'd0,
        u_top.u_core.u_ooo_core.fetch_req_fire_w ? 32'd1 : 32'd0,
        u_top.u_core.u_ooo_core.fetch_rsp_fire_w ? 32'd1 : 32'd0,
        u_top.u_core.u_ooo_core.fetch_rsp_enqueue_w ? 32'd1 : 32'd0,
        u_top.u_core.u_ooo_core.fetch_rsp_bypass_consumed_w ? 32'd1 : 32'd0,
        u_top.u_core.u_ooo_core.stop_pending_q ? 32'd1 : 32'd0,
        u_top.u_core.u_ooo_core.pending_branch_q ? 32'd1 : 32'd0,
        u_top.u_core.u_ooo_core.pending_jump_q ? 32'd1 : 32'd0,
        u_top.u_core.u_ooo_core.pending_mem_q ? 32'd1 : 32'd0,
	        u_top.u_core.u_ooo_core.synth_lane1_ret_pending_q ? 32'd1 : 32'd0,
	        u_top.u_core.u_ooo_core.branch_prefetch_req_fire_w ? 32'd1 : 32'd0,
	        (u_top.u_core.u_ooo_core.branch_prefetch_hit_available_w ||
	         u_top.u_core.u_ooo_core.jalr_prefetch_hit_available_w) ? 32'd1 : 32'd0,
        u_top.u_core.u_ooo_mem_bridge.mem0_req_fire_w ? 32'd1 : 32'd0,
        32'd0,  // mem1(双发射 load 第二端口)死硅删除:mem1_req_fire 恒 0
        (u_top.u_core.ooo_mem0_rsp_valid_w && u_top.u_core.ooo_mem0_rsp_ready_w) ? 32'd1 : 32'd0,
        32'd0,  // mem1_rsp_fire 恒 0(死硅删除)
        u_top.u_core.u_ooo_core.core_commit1_block_w ? 32'd1 : 32'd0,
        sim_ooo_fetch_busy_w ? 32'd1 : 32'd0,
        sim_ooo_mem_busy_w ? 32'd1 : 32'd0,
        sim_ooo_axi_wait_w ? 32'd1 : 32'd0,
        sim_ooo_hazard_busy_w ? 32'd1 : 32'd0,
        sim_ooo_branch_flush_w ? 32'd1 : 32'd0,
        sim_ooo_exception_busy_w ? 32'd1 : 32'd0,
        u_top.u_core.u_ooo_core.pending_branch_pc_q,
        u_top.u_core.u_ooo_core.pending_jump_pc_q
      );
`endif

      if (reset_syscon_terminal_w && !exit_reported_q) begin
        exit_reported_q <= 1'b1;
        if (reset_syscon_poweroff_w) begin
          $display("syscon-reset: poweroff requested value=0x%08x pc=0x%016x",
                   reset_syscon_write_value_w, debug_pc_o);
        end else if (reset_syscon_reboot_w) begin
          $display("syscon-reset: reboot requested value=0x%08x pc=0x%016x",
                   reset_syscon_write_value_w, debug_pc_o);
        end else begin
          $display("syscon-reset: test-finisher exit code=%0d value=0x%08x pc=0x%016x",
                   reset_syscon_write_value_w[31:16],
                   reset_syscon_write_value_w, debug_pc_o);
        end
        npc_exit_event(
          32'd0,
          32'd0,
          32'd1,
          reset_syscon_exit_code_w,
          debug_pc_o
        );
      end else if (core_exit_valid_w && !exit_reported_q) begin
        exit_reported_q <= 1'b1;
        npc_exit_event(
          core_exit_is_ebreak_w ? 32'd1 : 32'd0,
          core_exit_is_ecall_w ? 32'd1 : 32'd0,
          32'd0,
          core_exit_code_w,
          core_exit_pc_w
        );
      end

      if (core_trap_valid_w) begin
        npc_trap_event(
          {{(32-`TRAP_CAUSE_W){1'b0}}, core_trap_cause_w},
          core_trap_pc_w,
          core_trap_tval_w
        );
      end

      if (u_top.u_core.u_ooo_core.csr_trap_mem_valid_w) begin
        npc_handled_trap_event(
          32'd0,
          {{(32-`TRAP_CAUSE_W){1'b0}}, u_top.u_core.u_ooo_core.csr_trap_mem_cause_w},
          u_top.u_core.u_ooo_core.csr_trap_mem_pc_w,
          u_top.u_core.u_ooo_core.csr_trap_mem_tval_w
        );
      end

      // 阶段4 difftest 中断同步: NPC 取异步中断(csr_trap_irq)→ 报 kind=2(irq), 让 difftest 让 NEMU
      // raise 同中断(NPC 主导时刻)。中断 tval=0。
      if (u_top.u_core.u_ooo_core.csr_trap_irq_valid_w) begin
        npc_handled_trap_event(
          32'd2,
          {{(32-`TRAP_CAUSE_W){1'b0}}, u_top.u_core.u_ooo_core.csr_trap_irq_cause_w},
          u_top.u_core.u_ooo_core.csr_trap_irq_pc_w,
          64'd0
        );
      end

      if (u_top.u_core.u_ooo_core.csr_trap_ex_valid_w) begin
        npc_handled_trap_event(
          32'd1,
          {{(32-`TRAP_CAUSE_W){1'b0}}, u_top.u_core.u_ooo_core.csr_trap_ex_cause_w},
          u_top.u_core.u_ooo_core.csr_trap_ex_pc_w,
          u_top.u_core.u_ooo_core.csr_trap_ex_tval_w
        );
        // difftest: ecall/ebreak 走 pending-trap 通道, 不产生 ROB/ctrl commit,
        // ref 单步会停在 ecall 本身等待——在 trap 注入拍补一条 commit 事件
        // (GPR 不变, next=trap 目标), 让 ref 同步跨过这条指令。
        if ((u_top.u_core.u_ooo_core.csr_trap_ex_cause_w == `TRAP_CAUSE_W'd8) ||
            (u_top.u_core.u_ooo_core.csr_trap_ex_cause_w == `TRAP_CAUSE_W'd9) ||
            (u_top.u_core.u_ooo_core.csr_trap_ex_cause_w == `TRAP_CAUSE_W'd11) ||
            (u_top.u_core.u_ooo_core.csr_trap_ex_cause_w == `TRAP_CAUSE_W'd3)) begin
          npc_commit_event(
            u_top.u_core.u_ooo_core.csr_trap_ex_pc_w,
            (u_top.u_core.u_ooo_core.csr_trap_ex_cause_w == `TRAP_CAUSE_W'd3) ?
              32'h00100073 : 32'h00000073,
            u_top.u_core.u_ooo_core.csr_trap_target_w,
            32'd0,
            32'd0,
            64'd0,
            32'd0   // ecall/ebreak 补 commit 非 FP
          );
        end
      end

      if (u_top.u_core.u_ooo_core.csr_trap_irq_valid_w) begin
        npc_handled_trap_event(
          32'd2,
          {{(32-`TRAP_CAUSE_W){1'b0}}, u_top.u_core.u_ooo_core.pending_system_irq_cause_q},
          u_top.u_core.u_ooo_core.pending_system_pc_q,
          64'd0
        );
      end

    end
  end

  // ─────────────────────────────────────────────────────────────────────────────────────────
  // §5 三层观测模型 ② 层: OoO 前端取指重定向「组合汇合点」观测 checker(旁挂, 不进数据通路)。
  // 【P4 切消费点(2026-07-09)】mux 三元链已删(redirect PC 单源 = OooRedirectArbiter 赢家),
  // checker 同步重写: 死态哨兵(RDMUX-DEAD)照旧 + 单源透传结构守卫(RDMUX-ARB/DEFAULT-PC)。
  // 被观测信号经 XMR 从 u_top.u_core.u_ooo_core.u_frontend.u_fetch_request_mux 连入端口;
  // 仅 `+define+OOO_ASSERT` 时例化; facts 悬空 → DCE 零面积。① 层电路一行不动。
  // ─────────────────────────────────────────────────────────────────────────────────────────
`ifdef OOO_ASSERT
`define RDMUX_XMR u_top.u_core.u_ooo_core.u_frontend.u_fetch_request_mux
  OooRedirectMuxChecker u_ooo_rdmux_checker (
    .clk                          (clk),
    .rst                          (rst),
    .pending_jump_nolink_i        (`RDMUX_XMR.pending_jump_nolink_commit_i),
    .pending_jump_redir_i         (`RDMUX_XMR.pending_jump_redirect_after_dispatch_i),
    .redirect_valid_i             (`RDMUX_XMR.redirect_valid_i),
    .redirect_pc_i                (`RDMUX_XMR.redirect_pc_i),
    .redirect_fetch_pc_i          (`RDMUX_XMR.redirect_fetch_pc_o),
    .core_branch_resolve_next_pc_i(`RDMUX_XMR.core_branch_resolve_next_pc_i)
  );
`undef RDMUX_XMR
`endif

  // ─────────────────────────────────────────────────────────────────────────────────────────
  // §5 三层观测模型 ② 层: OoO 前端取指重定向「时序汇合点」观测 checker。
  // 被观测信号经 XMR 从 u_top.u_core.u_ooo_core.u_frontend.u_fetch_pc_outstanding 连入;
  // 【P4】E1 载荷口 csr_trap_target_i 已随 PC 写删除 → target 改自 u_frontend 作用域
  // (csr_trap_target_w), INV-S2 断言语义不变(E1 pre-mux 最高档 + trap 口 age0 恒胜)。
  // ─────────────────────────────────────────────────────────────────────────────────────────
`ifdef OOO_ASSERT
`define RDSEQ_XMR u_top.u_core.u_ooo_core.u_frontend.u_fetch_pc_outstanding
`define RDFE_XMR u_top.u_core.u_ooo_core.u_frontend
  OooRedirectSeqChecker u_ooo_rdseq_checker (
    .clk                             (clk),
    .rst                             (rst),
    .csr_trap_mem_valid_i            (`RDSEQ_XMR.csr_trap_mem_valid_i),
    .csr_trap_target_i               (`RDFE_XMR.csr_trap_target_w),
    .direct_frontend_flush_i         (`RDSEQ_XMR.direct_frontend_flush_i),
    .branch_resolve_untracked_i      (`RDSEQ_XMR.branch_resolve_untracked_i),
    .core_branch_resolve_misaligned_i(`RDSEQ_XMR.core_branch_resolve_misaligned_i),
    .pending_jump_resolve_ready_i    (`RDSEQ_XMR.pending_jump_resolve_ready_i),
    .next_fetch_pc_q                 (`RDSEQ_XMR.next_fetch_pc_q)
  );
`undef RDSEQ_XMR
`undef RDFE_XMR
`endif

  // 【P4 切消费点(2026-07-09)】OooRedirectMergeChecker(跨 Mux/Seq untracked 一致性 INV-M1)
  // 退役: 两汇合点消费同一 OooRedirectArbiter 赢家 wire, 跨器一致性由单源构造保证,
  // 对照物不复存在(文件与 SIM_TOP_SRCS 项一并删除, 见 filelist.mk)。

  // ─────────────────────────────────────────────────────────────────────────────────────────
  // §5 三层观测模型 ② 层: Sv39 HW-managed A/D 更新(Svadu)观测 checker(数据+取指双桥)。
  // XMR 从 u_top.u_core.u_ooo_{fetch,mem}_bridge.* 连入两桥的 walker + PTE 写信号。
  // 通用单桥模块实例化两次: 取指桥 ALLOW_D=0(只置 A) / 数据桥 ALLOW_D=1(置 A/D)。现状见 active fetch/mem AXI bridge spec。
  // ─────────────────────────────────────────────────────────────────────────────────────────
`ifdef OOO_ASSERT
`define ADF_XMR u_top.u_core.u_ooo_fetch_bridge
  OooAdUpdateChecker #(.ALLOW_D(1'b0)) u_ooo_fetch_adupd_checker (
    .clk            (clk),
    .rst            (rst),
    .state_i        (`ADF_XMR.state_q),
    .rvalid_i       (`ADF_XMR.ifu_axi_rvalid_i),
    .rdata_i        (`ADF_XMR.ifu_axi_rdata_i),
    .awvalid_i      (`ADF_XMR.ifu_axi_awvalid_o),
    .awaddr_i       (`ADF_XMR.ifu_axi_awaddr_o),
    .wvalid_i       (`ADF_XMR.ifu_axi_wvalid_o),
    .wstrb_i        (`ADF_XMR.ifu_axi_wstrb_o),
    .walk_pte_addr_i(`ADF_XMR.walk_pte_addr_w),
    .ad_pte_i       (`ADF_XMR.ad_pte_q)
  );
`undef ADF_XMR
`define ADM_XMR u_top.u_core.u_ooo_mem_bridge
  OooAdUpdateChecker #(.ALLOW_D(1'b1)) u_ooo_mem_adupd_checker (
    .clk            (clk),
    .rst            (rst),
    .state_i        (`ADM_XMR.state_q),
    .rvalid_i       (`ADM_XMR.lsu_axi_rvalid_i),
    .rdata_i        (`ADM_XMR.lsu_axi_rdata_i),
    .awvalid_i      (`ADM_XMR.lsu_axi_awvalid_o),
    .awaddr_i       (`ADM_XMR.lsu_axi_awaddr_o),
    .wvalid_i       (`ADM_XMR.lsu_axi_wvalid_o),
    .wstrb_i        (`ADM_XMR.lsu_axi_wstrb_o),
    .walk_pte_addr_i(`ADM_XMR.walk_pte_addr_w),
    .ad_pte_i       (`ADM_XMR.ad_pte_q)
  );
`undef ADM_XMR
`endif

  // ─────────────────────────────────────────────────────────────────────────────────────────
  // 【P5 刀 M】桥侧 req 寄存站跨模块守卫(mem_quiet 死锁家族, 立即断言形态):
  //   ① KM-STG-MIQ: 寄存站占用 ⇒ MIQ 非空——push 与进站(fire)同拍、pop 在 rsp 消费
  //      拍, 故独占谓词族(mem_idle/mem_amo_slot/mem_retire_quiet)自动把寄存站计入,
  //      任何消费点无需加 term; 若 MIQ push 漏记账或桥/MIQ 两侧 flush 源相位失配
  //      (桥=ooo_mem_flush_w vs MIQ=flush_i||checkpoint_restore_i, 双射义务), 本断言
  //      当拍抓获。
  //   ② KM-STG-CTX: 寄存站占用期 CSR 翻译上下文(satp/mstatus/priv/svpbmt)冻结——
  //      accept 推迟到 advance 拍的合法性依赖 serialize-at-retire(寄存站占用 ⇒
  //      mem_idle=0 ⇒ head0-CSR/trap 不能退休), advance 拍上下文必与 fire 拍一致。
  //      pretrans(SQ drain 落存, nokill 跨 flush 存活)豁免: 其 accept 跳过翻译/PMP,
  //      上下文不敏感, 且 trap 拍(mstatus/priv 更新)其站内存活属既定语义。
  // ─────────────────────────────────────────────────────────────────────────────────────────
`ifdef OOO_ASSERT
`define KM_BRG_XMR u_top.u_core.u_ooo_mem_bridge
`define KM_IBE_XMR u_top.u_core.u_ooo_core.u_execute_backend.u_core_slice.u_decode_backend.u_int_backend
  reg km_ctx_seen_q;
  reg [`XLEN-1:0] km_ctx_satp_q;
  reg [`XLEN-1:0] km_ctx_mstatus_q;
  reg [1:0] km_ctx_priv_q;
  reg km_ctx_svpbmt_q;
  // 武装计数：复位释放后延迟 3 拍才启用断言——x-assign 随机初始化下复位拉起前的
  // 起始拍会以随机 stg_valid/miq 态误触发($fatal 挂仿真;rv64uf-p-fadd 大节点回归
  // 首次暴露,module TB 不含 NpcSimTop 未覆盖)。km_arm_q 必须**声明初始化**:
  // 本工程 --x-initial fast 会给未显式初始化的 reg 填非零快速值(计数器可能
  // 直接=3 当拍武装),显式初始化不受其影响。(本文件 sim-only,声明初始化+过程赋值
  // 的潜在 process/init 混用告警由当前工具链在声明初始化语义下处理——观测
  // 计数器必须有确定初值,这正是意图。不要使用版本相关的 lint message pragma，
  // 否则旧版 Verilator 会把未知 message code 当作编译错误。)
  reg [1:0] km_arm_q = 2'b00;
  always @(posedge clk) begin
    if (rst) begin
      km_ctx_seen_q <= 1'b0;
      km_arm_q <= 2'b00;
    end else begin
      if (km_arm_q != 2'b11) begin
        km_arm_q <= km_arm_q + 2'b01;
      end
      // $time 门：Verilator 中声明初始化与第一个 posedge 存在调度竞争(@0 沿可能
      // 先于 initial 生效读到 x-initial fast 的非零填充值),仿真时刻是唯一与
      // 寄存器初始化顺序无关的武装依据;200 保守覆盖 TB 复位序列。
      if (($time > 64'd200) && (km_arm_q == 2'b11) &&
          `KM_BRG_XMR.stg_valid_q && `KM_IBE_XMR.miq_empty_w) begin
        $error("[KM-STG-MIQ] 桥寄存站占用但 MIQ 记账为空 @%0t", $time);
        $fatal;
      end
      if (($time > 64'd200) && (km_arm_q == 2'b11) &&
          `KM_BRG_XMR.stg_valid_q && !`KM_BRG_XMR.stg_pretrans_q &&
          km_ctx_seen_q &&
          ((`KM_BRG_XMR.satp_i != km_ctx_satp_q) ||
           (`KM_BRG_XMR.mstatus_i != km_ctx_mstatus_q) ||
           (`KM_BRG_XMR.priv_mode_i != km_ctx_priv_q) ||
           (`KM_BRG_XMR.svpbmt_en_i != km_ctx_svpbmt_q))) begin
        $error("[KM-STG-CTX] 寄存站占用期 CSR 翻译上下文被改写 @%0t", $time);
        $fatal;
      end
      if (`KM_BRG_XMR.mem0_req_fire_w) begin
        km_ctx_seen_q <= 1'b1;
        km_ctx_satp_q <= `KM_BRG_XMR.satp_i;
        km_ctx_mstatus_q <= `KM_BRG_XMR.mstatus_i;
        km_ctx_priv_q <= `KM_BRG_XMR.priv_mode_i;
        km_ctx_svpbmt_q <= `KM_BRG_XMR.svpbmt_en_i;
      end
    end
  end
`undef KM_BRG_XMR
`undef KM_IBE_XMR
`endif

endmodule
