# OooWriteback 子系统 wrapper Spec

## 1. 目标

把 `writeback/` 目录的 4 个 commit/retire owner 聚合到 `writeback/OooWriteback.v`，
让 `OooCoreTopGlue` 只对写回子系统做一次实例化。纯结构聚合，不新增逻辑、不改行为。
（抽取时为 5 个 owner；`OooFpCommitGate` 已随 FP 迁域 A 删除，FP 经 ROB 真 commit。）

## 2. 责任边界（内部 owner，行为不变）

| 内部 owner | 职责（不变） |
| --- | --- |
| `OooCommitOutputMux` | commit0/commit1 输出选择 |
| `OooControlCommitSequencer` | control commit 注册状态 |
| ~~`OooSyntheticLane1RetCommitGate`~~ **已 B4 物理删除（2026-07-04, 21c7fbe14）** | ~~synthetic lane1 return commit/drop 判定~~ capture≡0 自洽全零不动点→删除，CommitOutputMux 合成臂化简、跨模块输出 TopGlue 常量0 tie-off |
| ~~`OooSyntheticLane1RetSequencer`~~ **已 B4 物理删除（2026-07-04, 21c7fbe14）** | ~~synthetic lane1 return 注册状态~~ 同上；spec 归档 `history/ooo-synthetic-lane1-ret-sequencer.md` |

## 3. 接口与不变量

- wrapper 端口 = 4 个内部实例跨边界信号（2026-07 现状 87 个；`OooFpCommitGate` 删除前为 113 个）。
- glue 顶层 wire 名保留；commit 输出端口（`commit0_*_o`/`commit1_*_o`）由 wrapper
  输出直接驱动 glue 同名顶层输出端口。
- `synth_lane1_ret_commit_w` 被 `tb_ooo_core_top_glue` 以 `dut.synth_lane1_ret_commit_w`
  探测，故作为 wrapper **输出**保留（不下沉），保证探针不失效。
- wrapper 无结构参数（内部实例不使用 `OOO_*` 参数）。

## 4. 验证

- `make -C npc/rv64 lint` / build PASS；module testbench 103/103 PASS；
  official riscv-tests（177 项）0 FAIL。

## 5. 边界

只完成 writeback 子系统 wrapper 抽取；不改变 commit/retire/synthetic-ret 语义、
精确异常或 ROB retirement。
